package com.example.awaq_agromo.presentation.screens.forms

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.awaq_agromo.R
import com.example.awaq_agromo.presentation.component.buttons.CheckboxInputBox
import com.example.awaq_agromo.presentation.component.ui.HorizontalDotBar

/* ====== PALETA (alineada a lo que ya tienes) ====== */
private val BgLight = Color(0xFFF4F8EF)
private val AccentBorder = Color(0xFFBBD8A8)
private val GreenDark = Color(0xFF2E4A1F)
private val GreenInactive = Color(0xFFCBD5C0)
private val TextMuted = Color(0xFF4B4B4B)

/* ====== DATOS DEMO (puedes ligarlos a ViewModel luego) ====== */
private val cropOptions = listOf(
    "Algodón", "Arroz", "Café", "Cacao", "Cebada",
    "Frijol", "Maíz", "Papa", "Soya", "Trigo"
)

@Composable
fun GeneralCropInfoScreen(
    modifier: Modifier = Modifier,
    totalSteps: Int = 8,
    currentStep: Int = 1, // según tu mockup, parece estar en el paso 2/8
    selectedTag: String = "Maíz",
    onNext: () -> Unit = {}
) {
    var search by remember { mutableStateOf("") }
    val filtered = remember(search) {
        if (search.isBlank()) cropOptions else cropOptions.filter { it.contains(search, ignoreCase = true) }
    }
    // Estado controlado para cada checkbox
    val checkedMap = remember { mutableStateMapOf<String, Boolean>() }
    // Init por única vez
    LaunchedEffect(Unit) {
        cropOptions.forEach { if (checkedMap[it] == null) checkedMap[it] = (it == selectedTag) }
    }
    var sowingDate by remember { mutableStateOf("") }

    Surface(color = BgLight) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start
        ) {
            /* ===== TÍTULO + SUB ===== */
            Text(
                text = "Información general del cultivo",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                color = Color.Black
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Complete los datos que disponga; el resto puede omitirlo.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted
            )
            Spacer(Modifier.height(10.dp))

            /* ===== PROGRESS DOTS ===== */
            HorizontalDotBar(
                n = totalSteps,
                k = 2,
                modifier = Modifier.fillMaxWidth(),
                activeColor = GreenDark,
                inactiveColor = GreenInactive,
                inactiveAlpha = 1f
            )

            Spacer(Modifier.height(14.dp))

            /* ===== SECCIÓN: Ubicación y clima ===== */
            Text(
                text = "Ubicación y clima",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = Color.Black
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Ubicación del cultivo y condiciones climáticas al momento de toma de datos.",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
            Spacer(Modifier.height(10.dp))

            // Tarjeta principal de ubicación
            LocationCard()

            Spacer(Modifier.height(18.dp))

            /* ===== SECCIÓN: Variedad Cultivada ===== */
            Text(
                text = "Variedad cultivada",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = Color.Black
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "¿Qué cultivo y variedad tiene sembrado?",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
            Spacer(Modifier.height(10.dp))

            // Ilustración (ajusta el recurso si tu drawable se llama distinto)
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.agri), // <-- Cambia si tu recurso tiene otro nombre
                    contentDescription = "Ilustración agricultor",
                    modifier = Modifier
                        .fillMaxWidth(0.82f)
                        .aspectRatio(1.05f)
                )
            }
            Spacer(Modifier.height(12.dp))

            Text(
                text = "Seleccione el cultivo de la lista o ingréselo manualmente.",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Busca por cultivo", color = Color(0xFF7A7A7A)) },
                singleLine = true,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.LocationOn, // ícono de ejemplo
                        contentDescription = "Buscar cultivo",
                        tint = GreenDark
                    )
                },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GreenDark,
                    unfocusedBorderColor = AccentBorder,
                    cursorColor = GreenDark,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            Spacer(Modifier.height(10.dp))

            // Chip seleccionado (ejemplo: "Maíz ×")
            SelectedTagChip(
                label = selectedTag,
                onRemove = { /* si quieres permitir quitar el tag */ }
            )

            Spacer(Modifier.height(12.dp))

            // Lista de opciones con tu CheckboxInputBox (controlado)
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 320.dp) // para que no crezca infinito
            ) {
                items(filtered, key = { it }) { name ->
                    CheckboxInputBox(
                        label = name,
                        checked = checkedMap[name] == true,
                        onCheckedChange = { isChecked ->
                            // Si marcas uno, opcionalmente podrías desmarcar los demás (exclusivo)
                            checkedMap.keys.forEach { k -> checkedMap[k] = false }
                            checkedMap[name] = isChecked
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // Fecha de siembra
            OutlinedTextField(
                value = sowingDate,
                onValueChange = { sowingDate = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("dd/mm/aaaa") },
                singleLine = true,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.CalendarMonth,
                        contentDescription = "Fecha de siembra",
                        tint = GreenDark
                    )
                },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GreenDark,
                    unfocusedBorderColor = AccentBorder,
                    cursorColor = GreenDark,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            Spacer(Modifier.height(14.dp))

            Button(
                onClick = onNext,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GreenDark,
                    contentColor = Color.White,
                    disabledContainerColor = GreenInactive,
                    disabledContentColor = Color.White
                )
            ) {
                Text("Siguiente")
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}

/* ====== SUBCOMPONENTES ====== */

@Composable
private fun LocationCard() {
    OutlinedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(AccentBorder))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Encabezado: ciudad, depto, país + fecha
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.LocationOn,
                        contentDescription = null,
                        tint = GreenDark
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "Barichara, Santander COLOMBIA",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.Black
                    )
                }
                Spacer(Modifier.width(8.dp))
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text = "Lunes 25 Mayo 2025",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )

            Spacer(Modifier.height(12.dp))

            // Métricas clima
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                WeatherMetric(title = "Humedad", value = "48%")
                WeatherMetric(title = "Viento", value = "10 km/h")
                WeatherMetric(title = "Temperatura", value = "22°C")
            }
        }
    }
}

@Composable
private fun WeatherMetric(title: String, value: String) {
    OutlinedCard(

        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.outlinedCardColors(containerColor = BgLight),
        border = CardDefaults.outlinedCardBorder().copy(width = 1.dp, brush = androidx.compose.ui.graphics.SolidColor(AccentBorder))
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 10.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Spacer(Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = Color.Black
            )
        }
    }
}

@Composable
private fun SelectedTagChip(
    label: String,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(100))
            .background(Color.White)
            .border(width = 1.dp, color = AccentBorder, shape = RoundedCornerShape(100))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(GreenDark)
        )
        Spacer(Modifier.width(8.dp))
        Text(text = label, color = Color.Black, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.width(6.dp))
        Text(text = "×", color = TextMuted, style = MaterialTheme.typography.bodySmall)
        // Si quieres que realmente quite el chip, reemplaza el Text "×" por un IconButton que llame onRemove()
    }
}

/* ====== PREVIEW ====== */

@Preview(showBackground = true, widthDp = 360, heightDp = 1280)
@Composable
private fun GeneralCropInfoPreview() {
    MaterialTheme {
        GeneralCropInfoScreen()
    }
}