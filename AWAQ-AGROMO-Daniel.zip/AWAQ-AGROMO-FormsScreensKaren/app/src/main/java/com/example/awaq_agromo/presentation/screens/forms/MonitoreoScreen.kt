package com.example.awaq_agromo.presentation.screens.forms

import android.Manifest
import android.annotation.SuppressLint
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.awaq_agromo.R
import com.example.awaq_agromo.presentation.component.ui.HorizontalDotBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/* ====== PALETA ====== */
private val BgLight = Color(0xFFF4F8EF)       // fondo claro
private val AccentBorder = Color(0xFFBBD8A8)  // bordes suaves
private val GreenDark = Color(0xFF2E4A1F)     // botón, punto activo
private val GreenInactive = Color(0xFFCBD5C0) // puntos inactivos / iconos suaves
private val TextMuted = Color(0xFF4B4B4B)

@Composable
fun MonitoreoScreen(
    modifier: Modifier = Modifier,
    totalSteps: Int = 6,
    initialStep: Int = 0,
    onStepChange: (Int) -> Unit = {}
) {
    var step by remember { mutableStateOf(initialStep.coerceIn(0, (totalSteps - 1).coerceAtLeast(0))) }
    var manualCity by remember { mutableStateOf("") }

    // Estado mostrado arriba ("Monterrey" -> se actualiza al obtener la ubicación)
    var detectedPlace by remember { mutableStateOf("—") }

    val context = LocalContext.current

    // Launcher para pedir permisos
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val fine = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarse = perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fine || coarse) {
            // Permisos otorgados -> obtener ubicación
            fetchCurrentPlaceString(
                context = context,
                onPlace = { place -> detectedPlace = place },
                onFailure = { detectedPlace = it }
            )
        } else {
            detectedPlace = "Permiso de ubicación denegado"
        }
    }

    // Re-clampear step si cambian props
    LaunchedEffect(initialStep, totalSteps) {
        val maxIndex = (totalSteps - 1).coerceAtLeast(0)
        step = initialStep.coerceIn(0, maxIndex)
        onStepChange(step)
    }

    Surface(color = BgLight, tonalElevation = 0.dp) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "Registro del Cultivo",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                color = Color.Black
            )
            Spacer(Modifier.size(6.dp))
            Text(
                text = "Complete los datos que disponga; el resto puede omitirlo.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted
            )

            Spacer(Modifier.size(12.dp))

            HorizontalDotBar(
                n = totalSteps,
                k = step,
                modifier = Modifier.fillMaxWidth(),
                activeColor = GreenDark,
                inactiveColor = GreenInactive,
                inactiveAlpha = 1f
            )

            Spacer(Modifier.size(16.dp))

            // Título de sección
            Text(
                text = "Indique la ubicación de su cultivo",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = Color.Black
            )

            Spacer(Modifier.size(12.dp))

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ubi),
                    contentDescription = "Ilustración de ubicación",
                    modifier = Modifier
                        .fillMaxWidth(0.7f)
                        .aspectRatio(0.9f, matchHeightConstraintsFirst = false)
                )
            }

            Spacer(Modifier.size(12.dp))

            // Fila de ubicación detectada (se actualiza al usar mi ubicación)
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.material3.Icon(
                    imageVector = Icons.Outlined.LocationOn,
                    contentDescription = "Ubicación",
                    tint = GreenDark
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = detectedPlace,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.Black
                )
            }

            Spacer(Modifier.size(12.dp))

            // Botón para pedir y usar ubicación actual
            Button(
                onClick = {
                    locationPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = GreenDark,
                    disabledContainerColor = GreenInactive.copy(alpha = 0.4f),
                    disabledContentColor = Color.White
                )
            ) {
                Text("Usar mi ubicación actual")
            }

            Spacer(Modifier.size(10.dp))

            // Separador
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Ingresar manualmente",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted
                )
            }

            Spacer(Modifier.size(8.dp))

            OutlinedTextField(
                value = manualCity,
                onValueChange = { manualCity = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Busca por ciudad", color = Color(0xFF7A7A7A)) },
                singleLine = true,
                leadingIcon = {
                    androidx.compose.material3.Icon(
                        imageVector = Icons.Outlined.LocationOn,
                        contentDescription = "Buscar ciudad",
                        tint = GreenDark
                    )
                },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GreenDark,
                    unfocusedBorderColor = AccentBorder,
                    cursorColor = GreenDark,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            Spacer(Modifier.size(20.dp))

            Button(
                onClick = {
                    val maxIndex = (totalSteps - 1).coerceAtLeast(0)
                    if (step < maxIndex) {
                        step += 1
                        onStepChange(step)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                enabled = step < (totalSteps - 1).coerceAtLeast(0),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GreenDark,
                    contentColor = Color.White,
                    disabledContainerColor = GreenInactive,
                    disabledContentColor = Color.White
                )
            ) {
                Text("Siguiente")
            }

            Spacer(Modifier.size(8.dp))
        }
    }
}

/* ===================== Helpers de ubicación ===================== */

/**
 * Obtiene una cadena amigable con Geocoder (Ciudad, Estado, País) si es posible,
 * o "lat, lon" como fallback. Maneja LocationManager sin Play Services.
 */
@SuppressLint("MissingPermission")
private fun fetchCurrentPlaceString(
    context: android.content.Context,
    onPlace: (String) -> Unit,
    onFailure: (String) -> Unit
) {
    val lm = context.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager

    // 1) Intento rápido: lastKnownLocation
    val last: Location? =
        lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)

    if (last != null) {
        geocodeOrLatLon(context, last, onPlace)
        return
    }

    // 2) Solicitar una actualización (tomar la primera que llegue y cancelar)
    val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            geocodeOrLatLon(context, location, onPlace)
            lm.removeUpdates(this)
        }

        override fun onProviderDisabled(provider: String) {}
        override fun onProviderEnabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
    }

    try {
        // Preferir NETWORK para rapidez; si no, GPS
        val provider = when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) {
            onFailure("Proveedores de ubicación desactivados")
            return
        }
        lm.requestLocationUpdates(provider, /* minTime */ 0L, /* minDistance */ 0f, listener)
    } catch (t: Throwable) {
        onFailure("No se pudo obtener ubicación: ${t.message}")
    }
}

private fun geocodeOrLatLon(
    context: android.content.Context,
    loc: Location,
    onPlace: (String) -> Unit
) {
    // Geocoder puede lanzar excepciones o devolver vacío; usar try/fallback
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // API 33+: Geocoder con callback (pero aquí seguimos con versión sincrónica para simplicidad)
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val results = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
            if (!results.isNullOrEmpty()) {
                val a = results[0]
                val city = a.locality ?: a.subAdminArea ?: ""
                val state = a.adminArea ?: ""
                val country = a.countryName ?: ""
                val label = listOf(city, state, country).filter { it.isNotBlank() }.joinToString(", ")
                if (label.isNotBlank()) {
                    onPlace(label)
                    return
                }
            }
        } else {
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val results = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
            if (!results.isNullOrEmpty()) {
                val a = results[0]
                val city = a.locality ?: a.subAdminArea ?: ""
                val state = a.adminArea ?: ""
                val country = a.countryName ?: ""
                val label = listOf(city, state, country).filter { it.isNotBlank() }.joinToString(", ")
                if (label.isNotBlank()) {
                    onPlace(label)
                    return
                }
            }
        }
    } catch (_: Throwable) {
        // ignorar y caer a lat/lon
    }
    onPlace("${"%.5f".format(loc.latitude)}, ${"%.5f".format(loc.longitude)}")
}


@Preview(showBackground = true, widthDp = 360, heightDp = 800)
@Composable
private fun MonitoreoPreview() {
    MaterialTheme {
        MonitoreoScreen(
            totalSteps = 8,
            initialStep = 1
        )
    }
}