package com.example.awaq_agromo.presentation.component.buttons

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

// Paleta (mantengo tus colores)
val PrincipalPrimary = Color(0xFF4E7029)
val Primary900 = Color(0xFF344E18)
val Primary50 = Color(0xFFFAFFF5)

val PrincipalSecondary = Color(0xFFA5BE00)

val PrincipalNeutral = Color(0xFFF4F7DC)
val Neutral400 = Color(0xFFB0B396)

val Black = Color(0xFF1D1B20)
val PrincipalAlert = Color(0xFFBC4749)
val PrincipalWarning = Color(0xFFF2D646)

// Si quieres que el relleno del cuadro sea transparente cuando está checked
val CustomCheckColor = Color.Transparent

/**
 * CheckboxInputBox controlado (state hoisting).
 *
 * @param label Texto del campo.
 * @param checked Estado actual.
 * @param onCheckedChange Callback al cambiar.
 * @param modifier Modificador externo.
 */
@Composable
fun CheckboxInputBox(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .toggleable(
                value = checked,
                role = Role.Checkbox,
                onValueChange = onCheckedChange
            )
    ) {
        OutlinedTextField(
            value = "",
            onValueChange = { /* readOnly */ },
            readOnly = true,
            label = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = label)
                    Spacer(modifier = Modifier.weight(1f))
                    // El Checkbox no maneja el click directamente para evitar doble evento.
                    Checkbox(
                        checked = checked,
                        onCheckedChange = null, // controlado por el contenedor toggleable
                        colors = CheckboxDefaults.colors(
                            checkedColor = CustomCheckColor,
                            uncheckedColor = PrincipalPrimary,
                            checkmarkColor = Primary900, // color del "tick"
                            disabledCheckedColor = CustomCheckColor.copy(alpha = 0.4f),
                            disabledUncheckedColor = PrincipalPrimary.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.size(24.dp)
                    )
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrincipalPrimary,
                unfocusedBorderColor = Primary900,
                focusedContainerColor = Primary50,
                unfocusedContainerColor = Color.Transparent,
                cursorColor = Color.Transparent
            ),
            singleLine = true
        )
    }
}

/* --------- PREVIEW CONTROLADO --------- */

@Preview(showBackground = true, widthDp = 360, name = "CheckboxInputBox Preview - Checked")
@Composable
private fun CheckboxInputBoxPreviewChecked() {
    var checked = true
    CheckboxInputBox(
        label = "Acepto términos y condiciones",
        checked = checked,
        onCheckedChange = { checked = it }
    )
}

@Preview(showBackground = true, widthDp = 360, name = "CheckboxInputBox Preview - Unchecked")
@Composable
private fun CheckboxInputBoxPreviewUnchecked() {
    var checked = false
    CheckboxInputBox(
        label = "Deseo recibir actualizaciones",
        checked = checked,
        onCheckedChange = { checked = it }
    )
}